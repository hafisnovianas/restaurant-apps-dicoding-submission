import './restaurant-item.js';
import './restaurant-list.js';
import './footer-bar.js';
import './restaurant-detail.js';
import './restaurant-menus.js';
import './restaurant-reviews.js';
import './add-review.js';